(function (root, factory) {
  if (typeof module === 'object' && module.exports) {
    module.exports = factory(globalThis, require('./document-composer.js'), require('./print/report-shell.js'));
  } else {
    root.CoverageFitPrintRendererRegistry = factory(root, root.CoverageFitPrintDocumentComposer, root.CoverageFitPrintReportShell);
  }
})(typeof window !== 'undefined' ? window : globalThis, function (root, defaultComposer, defaultReportShell) {
  'use strict';

  const VERSION = '0.2.0';
  const DEFAULT_RENDERER_TYPE = 'html';
  const renderers = new Map();
  let defaultRendererType = DEFAULT_RENDERER_TYPE;

  function deepFreeze(value) {
    if (!value || typeof value !== 'object' || Object.isFrozen(value)) return value;
    Object.keys(value).forEach(key => deepFreeze(value[key]));
    return Object.freeze(value);
  }

  function clone(value) {
    if (value == null) return value;
    try { return JSON.parse(JSON.stringify(value)); }
    catch (error) { return null; }
  }

  function normalizeType(type) {
    if (typeof type !== 'string' || !type.trim()) {
      throw createRegistryError('PRINT_RENDERER_TYPE_INVALID', 'Renderer type must be a non-empty string.', { type });
    }
    return type.trim().toLowerCase();
  }

  function createRegistryError(code, message, details) {
    const error = new Error(message);
    error.name = 'CoverageFitPrintRendererRegistryError';
    error.code = code;
    error.details = deepFreeze(clone(details) || {});
    return error;
  }

  function normalizeCapabilities(renderer, metadata) {
    const source = metadata?.capabilities || renderer.capabilities || [];
    const values = Array.isArray(source) ? source : Object.keys(source || {}).filter(key => source[key]);
    return deepFreeze(Array.from(new Set(values
      .filter(value => typeof value === 'string' && value.trim())
      .map(value => value.trim().toLowerCase()))));
  }

  function normalizeMetadata(type, renderer, options) {
    const supplied = options?.metadata || {};
    return deepFreeze({
      type,
      id: typeof supplied.id === 'string' && supplied.id.trim() ? supplied.id.trim() : (renderer.id || type),
      name: typeof supplied.name === 'string' && supplied.name.trim() ? supplied.name.trim() : (renderer.name || `${type.toUpperCase()} Renderer`),
      version: typeof supplied.version === 'string' && supplied.version.trim() ? supplied.version.trim() : (renderer.version || '1.0.0'),
      mediaType: typeof supplied.mediaType === 'string' && supplied.mediaType.trim() ? supplied.mediaType.trim() : (renderer.mediaType || null),
      extension: typeof supplied.extension === 'string' && supplied.extension.trim() ? supplied.extension.trim().replace(/^\./, '') : (renderer.extension || null),
      capabilities: normalizeCapabilities(renderer, supplied),
      production: supplied.production !== false,
      certified: supplied.certified === true,
      registeredAt: new Date().toISOString()
    });
  }

  function validateRenderer(type, renderer) {
    const errors = [];
    if (!renderer || typeof renderer !== 'object') errors.push('Renderer must be an object.');
    if (renderer && typeof renderer.render !== 'function') errors.push('Renderer must implement render(model, options).');
    if (renderer && renderer.version != null && (typeof renderer.version !== 'string' || !renderer.version.trim())) {
      errors.push('Renderer version must be a non-empty string when provided.');
    }
    return deepFreeze({ type, valid: errors.length === 0, errors });
  }

  function registerRenderer(type, renderer, options) {
    const normalizedType = normalizeType(type);
    const settings = options || {};
    const validation = validateRenderer(normalizedType, renderer);
    if (!validation.valid) {
      throw createRegistryError('PRINT_RENDERER_INVALID', `Renderer ${normalizedType} failed registration validation.`, { type: normalizedType, errors: validation.errors });
    }
    if (renderers.has(normalizedType) && settings.replace !== true) {
      throw createRegistryError('PRINT_RENDERER_DUPLICATE', `Renderer ${normalizedType} is already registered.`, { type: normalizedType });
    }

    const entry = Object.freeze({
      type: normalizedType,
      renderer,
      metadata: normalizeMetadata(normalizedType, renderer, settings)
    });
    renderers.set(normalizedType, entry);
    if (settings.default === true) defaultRendererType = normalizedType;
    return entry.metadata;
  }

  function unregisterRenderer(type) {
    const normalizedType = normalizeType(type);
    if (!renderers.has(normalizedType)) return false;
    renderers.delete(normalizedType);
    if (defaultRendererType === normalizedType) {
      defaultRendererType = renderers.has(DEFAULT_RENDERER_TYPE) ? DEFAULT_RENDERER_TYPE : (renderers.keys().next().value || DEFAULT_RENDERER_TYPE);
    }
    return true;
  }

  function getRenderer(type) {
    if (type == null || type === '') return getDefaultRenderer();
    const entry = renderers.get(normalizeType(type));
    return entry ? entry.renderer : null;
  }

  function getRendererMetadata(type) {
    const normalizedType = normalizeType(type);
    return renderers.get(normalizedType)?.metadata || null;
  }

  function hasRenderer(type) {
    try { return renderers.has(normalizeType(type)); }
    catch (error) { return false; }
  }

  function listRenderers(options) {
    const settings = options || {};
    const entries = Array.from(renderers.values());
    if (settings.detailed === true || settings.metadata === true) return deepFreeze(entries.map(entry => entry.metadata));
    return deepFreeze(entries.map(entry => entry.type));
  }

  function setDefaultRenderer(type) {
    const normalizedType = normalizeType(type);
    if (!renderers.has(normalizedType)) {
      throw createRegistryError('PRINT_RENDERER_NOT_FOUND', `Cannot set unknown renderer ${normalizedType} as default.`, { type: normalizedType, availableRenderers: listRenderers() });
    }
    defaultRendererType = normalizedType;
    return defaultRendererType;
  }

  function getDefaultRendererType() { return defaultRendererType; }
  function getDefaultRenderer() { return renderers.get(defaultRendererType)?.renderer || null; }

  function resolveRenderer(type) {
    const resolvedType = type == null || type === '' ? defaultRendererType : normalizeType(type);
    const entry = renderers.get(resolvedType);
    if (!entry) {
      throw createRegistryError('PRINT_RENDERER_NOT_FOUND', `Unknown print renderer: ${resolvedType}.`, { type: resolvedType, availableRenderers: listRenderers() });
    }
    return Object.freeze({ type: resolvedType, renderer: entry.renderer, metadata: entry.metadata });
  }

  function supports(type, capability) {
    if (typeof capability !== 'string' || !capability.trim()) return false;
    const metadata = getRendererMetadata(type);
    return Boolean(metadata && metadata.capabilities.includes(capability.trim().toLowerCase()));
  }

  function getDiagnostics() {
    const metadata = listRenderers({ detailed: true });
    const defaultAvailable = renderers.has(defaultRendererType);
    return deepFreeze({
      valid: defaultAvailable && metadata.every(item => item.type && item.version),
      version: VERSION,
      rendererCount: metadata.length,
      defaultRendererType,
      defaultAvailable,
      renderers: metadata,
      warnings: defaultAvailable ? [] : [`Default renderer ${defaultRendererType} is not registered.`]
    });
  }

  function resolveComposer(options) {
    const composer = options?.documentComposer || defaultComposer || root.CoverageFitPrintDocumentComposer || null;
    if (!composer || typeof composer.compose !== 'function') {
      throw createRegistryError('PRINT_DOCUMENT_COMPOSER_UNAVAILABLE', 'The HTML renderer requires the CoverageFit document composer.', {});
    }
    return composer;
  }


  function resolveReportShell(options) {
    const shell = options?.reportShell || defaultReportShell || root.CoverageFitPrintReportShell || null;
    if (!shell || typeof shell.compose !== 'function') {
      throw createRegistryError('PRINT_REPORT_SHELL_UNAVAILABLE', 'The HTML renderer requires the CoverageFit report shell.', {});
    }
    return shell;
  }

  function normalizeSectionOutput(section, output) {
    if (typeof output === 'string') {
      return deepFreeze({ id: section.id, html: output, outputType: 'string' });
    }
    if (!output || typeof output !== 'object' || Array.isArray(output)) {
      throw createRegistryError('PRINT_SECTION_OUTPUT_INVALID', `Section ${section.id} returned an invalid render output.`, { sectionId: section.id, outputType: typeof output });
    }
    if (output.id && output.id !== section.id) {
      throw createRegistryError('PRINT_SECTION_OUTPUT_ID_MISMATCH', `Section ${section.id} returned output for ${output.id}.`, { sectionId: section.id, outputId: output.id });
    }
    return deepFreeze({
      ...clone(output),
      id: section.id,
      html: typeof output.html === 'string' ? output.html : '',
      outputType: 'object'
    });
  }

  function renderComposedSections(document, model, options) {
    const sectionOptions = deepFreeze(clone(options?.sectionOptions) || {});
    return deepFreeze(document.sections.map(section => {
      if (!section.definition || typeof section.definition.render !== 'function') {
        throw createRegistryError('PRINT_SECTION_RENDERER_MISSING', `Section ${section.id} does not implement render(model, options).`, { sectionId: section.id });
      }
      const output = section.definition.render(model, sectionOptions);
      return normalizeSectionOutput(section, output);
    }));
  }

  const PRINT_DOCUMENT_CSS = ':root{--cf-navy:#102f46;--cf-blue:#1f5f86;--cf-ink:#172b38;--cf-muted:#627681;--cf-line:#dce5e9;--cf-soft:#f4f7f8;--cf-warm:#f8f4ec;--cf-green:#26745b;--cf-amber:#a86d20}*{box-sizing:border-box}.cf-report-cover{width:8.5in;min-height:11in;margin:0 auto;padding:.72in .72in .55in;background:linear-gradient(145deg,#102f46,#173f5a);color:#fff;display:flex;flex-direction:column;break-after:page;page-break-after:always}.cf-shell-cover-brand{font-size:25px;font-weight:850;letter-spacing:-.04em}.cf-shell-cover-brand span{font-size:8px;vertical-align:top}.cf-shell-cover-main{margin:auto 0}.cf-shell-cover-eyebrow{margin:0 0 14px;color:#b8d6e7;font-size:10px;font-weight:800;letter-spacing:.16em;text-transform:uppercase}.cf-report-cover h1{max-width:6.4in;margin:0;font-size:44px;line-height:1.04;letter-spacing:-.045em}.cf-shell-cover-client{margin:22px 0 0;font-size:18px;font-weight:700}.cf-shell-cover-property{margin:7px 0 0;color:#cbdce5;font-size:12px}.cf-shell-cover-contact{display:flex;flex-direction:column;gap:4px;margin-top:18px;color:#b8d6e7;font-size:9px;line-height:1.45}.cf-shell-cover-contact strong{color:#fff}.cf-shell-cover-meta{display:grid;grid-template-columns:1fr 1fr;gap:28px;padding-top:22px;border-top:1px solid rgba(255,255,255,.25)}.cf-shell-cover-meta span{display:block;color:#b8d6e7;font-size:8px;font-weight:800;letter-spacing:.12em;text-transform:uppercase}.cf-shell-cover-meta strong{display:block;margin-top:7px;font-size:11px;line-height:1.45}.cf-report-cover>footer{display:flex;justify-content:space-between;gap:20px;margin-top:28px;color:#b8d6e7;font-size:8px}.cf-report-running-header,.cf-report-running-footer{display:none}.cf-report-body{display:block}html{background:#eef2f4}body{margin:0;padding:40px 20px;color:var(--cf-ink);font-family:Inter,-apple-system,BlinkMacSystemFont,"Segoe UI",Arial,sans-serif;line-height:1.5}.cf-print-section{max-width:8.5in;margin:0 auto;background:#fff;box-shadow:0 18px 55px rgba(16,47,70,.12)}.cf-executive-summary{min-height:11in;padding:.62in .66in .52in;display:flex;flex-direction:column;gap:28px}.cf-exec-masthead{display:flex;justify-content:space-between;gap:24px;padding-bottom:24px;border-bottom:3px solid var(--cf-navy)}.cf-exec-eyebrow,.cf-exec-card-label,.cf-exec-panel-heading p,.cf-exec-context span{margin:0;color:var(--cf-blue);font-size:10px;font-weight:800;letter-spacing:.14em;text-transform:uppercase}.cf-exec-masthead h1{margin:7px 0 6px;color:var(--cf-navy);font-size:34px;line-height:1.08;letter-spacing:-.03em}.cf-exec-client{margin:0;color:var(--cf-muted);font-size:14px}.cf-exec-brand{align-self:flex-start;color:var(--cf-navy);font-size:21px;font-weight:850;letter-spacing:-.04em}.cf-exec-brand span{font-size:8px;vertical-align:top}.cf-exec-context{display:grid;grid-template-columns:1.3fr .75fr 1fr;gap:18px}.cf-exec-context>div{padding-right:18px;border-right:1px solid var(--cf-line)}.cf-exec-context>div:last-child{border-right:0}.cf-exec-context strong,.cf-exec-context small{display:block}.cf-exec-context strong{margin-top:6px;font-size:13px;line-height:1.35}.cf-exec-context small{margin-top:3px;color:var(--cf-muted);font-size:10px}.cf-exec-hero-grid{display:grid;grid-template-columns:1fr 2.05fr;gap:22px}.cf-exec-score-card,.cf-exec-summary-card,.cf-exec-panel{border:1px solid var(--cf-line);border-radius:14px;break-inside:avoid;page-break-inside:avoid}.cf-exec-score-card{padding:24px;background:var(--cf-navy);color:#fff}.cf-exec-score-card .cf-exec-card-label{color:#b8d6e7}.cf-exec-score-value{display:flex;align-items:flex-end;gap:6px;margin:18px 0 2px}.cf-exec-score-value strong{font-size:58px;line-height:.9;letter-spacing:-.06em}.cf-exec-score-value span{padding-bottom:5px;color:#cbdce5;font-size:13px}.cf-exec-score-band{margin:12px 0 0;font-weight:750}.cf-exec-score-note{margin:14px 0 0;color:#cbdce5;font-size:10px;line-height:1.45}.cf-exec-summary-card{padding:25px 28px;background:linear-gradient(145deg,#fff,#f8fafb)}.cf-exec-summary-card h2{margin:8px 0 12px;color:var(--cf-navy);font-size:21px;line-height:1.25}.cf-exec-summary-card>p:last-of-type{margin:0;color:var(--cf-muted);font-size:13px}.cf-exec-strengths{display:flex;flex-wrap:wrap;gap:7px;margin-top:18px}.cf-exec-strength{padding:6px 9px;border-radius:999px;background:#eaf4ef;color:var(--cf-green);font-size:10px;font-weight:700}.cf-exec-action-grid{display:grid;grid-template-columns:1fr 1fr;gap:22px}.cf-exec-panel{padding:23px}.cf-exec-panel-heading{display:flex;align-items:flex-start;gap:12px;margin-bottom:18px}.cf-exec-panel-heading>span{display:grid;place-items:center;width:31px;height:31px;border-radius:50%;background:var(--cf-soft);color:var(--cf-blue);font-size:10px;font-weight:850}.cf-exec-panel-heading h2{margin:3px 0 0;color:var(--cf-navy);font-size:17px}.cf-exec-priority-list,.cf-exec-next-list{display:grid;gap:12px;margin:0;padding:0;list-style:none}.cf-exec-priority-list li,.cf-exec-next-list li{display:grid;grid-template-columns:25px 1fr;gap:10px;align-items:start;padding-top:12px;border-top:1px solid var(--cf-line);font-size:12px}.cf-exec-list-number{display:grid;place-items:center;width:22px;height:22px;border-radius:6px;background:var(--cf-warm);color:var(--cf-amber);font-size:9px;font-weight:850}.cf-exec-next-list .cf-exec-list-number{background:#eaf4ef;color:var(--cf-green)}.cf-exec-empty{margin:0;color:var(--cf-muted);font-size:12px;font-style:italic}.cf-exec-footer-note{margin-top:auto;padding-top:18px;border-top:1px solid var(--cf-line);color:var(--cf-muted);font-size:9px;line-height:1.5}.cf-exec-footer-note strong{color:var(--cf-navy)}.cf-property-summary{padding:.55in .62in;display:flex;flex-direction:column;gap:24px}.cf-property-header{display:flex;justify-content:space-between;gap:24px;padding-bottom:20px;border-bottom:2px solid var(--cf-navy)}.cf-property-eyebrow{margin:0;color:var(--cf-blue);font-size:10px;font-weight:800;letter-spacing:.14em;text-transform:uppercase}.cf-property-header h1{margin:6px 0;color:var(--cf-navy);font-size:30px}.cf-property-header p{margin:0;color:var(--cf-muted)}.cf-property-kicker{color:var(--cf-navy);font-weight:850}.cf-property-group{break-inside:avoid;page-break-inside:avoid}.cf-property-group h2{margin:0 0 12px;color:var(--cf-navy);font-size:17px}.cf-property-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:12px;margin:0}.cf-property-fact{padding:14px;border:1px solid var(--cf-line);border-radius:10px;background:#fff}.cf-property-fact dt{color:var(--cf-blue);font-size:9px;font-weight:800;letter-spacing:.08em;text-transform:uppercase}.cf-property-fact dd{margin:6px 0 0;font-size:13px;font-weight:700}.cf-property-risks ul{margin:0;padding-left:20px}.cf-property-risks li,.cf-property-risks p{font-size:12px;color:var(--cf-muted)}.cf-property-summary{padding:.55in .62in .46in;display:flex;flex-direction:column;gap:22px;min-height:11in}.cf-property-header{display:flex;justify-content:space-between;gap:24px;padding-bottom:20px;border-bottom:3px solid var(--cf-navy)}.cf-property-heading-copy{max-width:72%}.cf-property-eyebrow{margin:0;color:var(--cf-blue);font-size:10px;font-weight:800;letter-spacing:.14em;text-transform:uppercase}.cf-property-header h1{margin:7px 0 6px;color:var(--cf-navy);font-size:32px;line-height:1.1;letter-spacing:-.03em}.cf-property-address{margin:0;color:var(--cf-muted);font-size:14px}.cf-property-brand{align-self:flex-start;color:var(--cf-navy);font-size:20px;font-weight:850;letter-spacing:-.04em;text-align:right}.cf-property-brand span{font-size:8px;vertical-align:top}.cf-property-brand small{display:block;margin-top:4px;color:var(--cf-muted);font-size:8px;font-weight:700;letter-spacing:.12em;text-transform:uppercase}.cf-property-overview{display:grid;grid-template-columns:repeat(4,1fr);border:1px solid var(--cf-line);border-radius:12px;background:linear-gradient(145deg,#fff,#f7f9fa);overflow:hidden;break-inside:avoid;page-break-inside:avoid}.cf-property-overview>div{padding:15px 16px;border-right:1px solid var(--cf-line)}.cf-property-overview>div:last-child{border-right:0}.cf-property-overview span,.cf-property-section-heading span,.cf-property-coverage-card dt{display:block;color:var(--cf-blue);font-size:8px;font-weight:800;letter-spacing:.1em;text-transform:uppercase}.cf-property-overview strong{display:block;margin-top:5px;color:var(--cf-navy);font-size:12px;line-height:1.35}.cf-property-main-grid{display:grid;grid-template-columns:1.35fr 1fr;gap:18px;align-items:start}.cf-property-panel{padding:20px;border:1px solid var(--cf-line);border-radius:13px;background:#fff;break-inside:avoid;page-break-inside:avoid}.cf-property-section-heading{display:flex;gap:12px;align-items:flex-start;margin-bottom:16px}.cf-property-section-heading>p{display:grid;place-items:center;flex:0 0 30px;width:30px;height:30px;margin:0;border-radius:8px;background:var(--cf-soft);color:var(--cf-blue);font-size:9px;font-weight:850}.cf-property-section-heading h2{margin:3px 0 0;color:var(--cf-navy);font-size:16px;line-height:1.25}.cf-property-grid{display:grid;grid-template-columns:repeat(2,1fr);gap:9px;margin:0}.cf-property-fact{padding:12px;border:1px solid var(--cf-line);border-radius:9px;background:#fbfcfc}.cf-property-fact dt{color:var(--cf-muted);font-size:8px;font-weight:800;letter-spacing:.08em;text-transform:uppercase}.cf-property-fact dd{margin:5px 0 0;color:var(--cf-ink);font-size:12px;font-weight:750;line-height:1.35}.cf-property-coverage-cards{display:grid;gap:9px;margin:0}.cf-property-coverage-card{padding:13px 14px;border-left:4px solid var(--cf-blue);border-radius:0 9px 9px 0;background:var(--cf-soft)}.cf-property-coverage-card dd{margin:5px 0 2px;color:var(--cf-navy);font-size:16px;font-weight:850;line-height:1.15}.cf-property-coverage-card small{display:block;color:var(--cf-muted);font-size:8px;line-height:1.4}.cf-property-coverage-note{margin:12px 0 0;color:var(--cf-muted);font-size:8px;line-height:1.5}.cf-property-risks{background:linear-gradient(145deg,#fff,#fbfaf7)}.cf-property-risk-list{display:grid;grid-template-columns:repeat(2,1fr);gap:9px;margin:0;padding:0;list-style:none}.cf-property-risk-list li{display:grid;grid-template-columns:27px 1fr;gap:10px;align-items:start;padding:11px;border:1px solid #eadfcb;border-radius:9px;background:#fff}.cf-property-risk-list li>span{display:grid;place-items:center;width:24px;height:24px;border-radius:6px;background:var(--cf-warm);color:var(--cf-amber);font-size:8px;font-weight:850}.cf-property-risk-list p{margin:2px 0 0;color:var(--cf-ink);font-size:10px;line-height:1.4}.cf-property-empty{padding:16px;border:1px dashed var(--cf-line);border-radius:9px;background:#fafcfc}.cf-property-empty strong{color:var(--cf-navy);font-size:11px}.cf-property-empty p{margin:5px 0 0;color:var(--cf-muted);font-size:9px}.cf-property-footer{display:flex;justify-content:space-between;gap:24px;margin-top:auto;padding-top:15px;border-top:1px solid var(--cf-line);color:var(--cf-muted);font-size:8px;line-height:1.45}.cf-property-footer p{margin:0}.cf-property-footer p:first-child{max-width:60%}.cf-property-footer strong{color:var(--cf-navy)}.cf-recommendations{padding:.55in .62in .46in;display:flex;flex-direction:column;gap:22px;min-height:11in}.cf-rec-header{display:grid;grid-template-columns:1fr auto;gap:24px;align-items:start;padding-bottom:20px;border-bottom:3px solid var(--cf-navy)}.cf-rec-eyebrow{margin:0;color:var(--cf-blue);font-size:10px;font-weight:800;letter-spacing:.14em;text-transform:uppercase}.cf-rec-header h1{margin:7px 0 9px;color:var(--cf-navy);font-size:32px;line-height:1.1;letter-spacing:-.03em}.cf-rec-intro{max-width:620px;margin:0;color:var(--cf-muted);font-size:11px;line-height:1.55}.cf-rec-count{display:grid;place-items:center;min-width:82px;padding:13px 16px;border-radius:12px;background:var(--cf-navy);color:#fff;text-align:center}.cf-rec-count strong{font-size:27px;line-height:1}.cf-rec-count span{margin-top:4px;color:#cbdce5;font-size:8px;font-weight:800;letter-spacing:.12em;text-transform:uppercase}.cf-rec-list{display:grid;gap:14px}.cf-rec-card{border:1px solid var(--cf-line);border-left:5px solid var(--cf-blue);border-radius:12px;background:#fff;overflow:hidden;break-inside:avoid;page-break-inside:avoid}.cf-rec-priority-critical{border-left-color:#a43b36}.cf-rec-priority-high{border-left-color:var(--cf-amber)}.cf-rec-priority-medium{border-left-color:#4a7895}.cf-rec-priority-low{border-left-color:var(--cf-green)}.cf-rec-card-header{display:grid;grid-template-columns:38px 1fr;gap:13px;padding:16px 18px 12px;background:linear-gradient(145deg,#fff,#f8fafb)}.cf-rec-index{display:grid;place-items:center;width:32px;height:32px;border-radius:8px;background:var(--cf-soft);color:var(--cf-blue);font-size:9px;font-weight:850}.cf-rec-labels{display:flex;flex-wrap:wrap;gap:7px;margin-bottom:6px}.cf-rec-priority,.cf-rec-category{display:inline-flex;padding:4px 7px;border-radius:999px;font-size:7px;font-weight:850;letter-spacing:.1em;text-transform:uppercase}.cf-rec-priority{background:var(--cf-warm);color:var(--cf-amber)}.cf-rec-priority-critical .cf-rec-priority{background:#f7e9e8;color:#943731}.cf-rec-priority-low .cf-rec-priority{background:#eaf4ef;color:var(--cf-green)}.cf-rec-category{background:#eaf1f5;color:var(--cf-blue)}.cf-rec-title-block h2{margin:0;color:var(--cf-navy);font-size:17px;line-height:1.25}.cf-rec-topic{margin:4px 0 0;color:var(--cf-muted);font-size:10px}.cf-rec-card-body{display:grid;grid-template-columns:1fr 1fr;gap:0;border-top:1px solid var(--cf-line)}.cf-rec-detail{padding:14px 18px}.cf-rec-detail+ .cf-rec-detail{border-left:1px solid var(--cf-line)}.cf-rec-detail h3,.cf-rec-question span{margin:0 0 5px;color:var(--cf-blue);font-size:8px;font-weight:850;letter-spacing:.1em;text-transform:uppercase}.cf-rec-detail p,.cf-rec-question p{margin:0;color:var(--cf-ink);font-size:10px;line-height:1.5}.cf-rec-question{grid-column:1/-1;padding:11px 18px;border-top:1px solid var(--cf-line);background:#fbfcfc}.cf-rec-question p{font-style:italic}.cf-rec-footer{display:flex;justify-content:space-between;gap:24px;margin-top:auto;padding-top:15px;border-top:1px solid var(--cf-line);color:var(--cf-muted);font-size:8px;line-height:1.45}.cf-rec-footer p{margin:0}.cf-rec-footer p:first-child{max-width:65%}.cf-rec-footer strong{color:var(--cf-navy)}.cf-rec-heading-copy{max-width:72%}.cf-rec-brand{align-self:flex-start;color:var(--cf-navy);font-size:20px;font-weight:850;letter-spacing:-.04em;text-align:right}.cf-rec-brand span{font-size:8px;vertical-align:top}.cf-rec-brand small{display:block;margin-top:4px;color:var(--cf-muted);font-size:8px;font-weight:700;letter-spacing:.12em;text-transform:uppercase}.cf-rec-summary-strip{display:grid;grid-template-columns:auto 1fr 1.25fr;gap:16px;align-items:stretch;padding:14px;border:1px solid var(--cf-line);border-radius:13px;background:linear-gradient(145deg,#fff,#f7f9fa);break-inside:avoid;page-break-inside:avoid}.cf-rec-summary-strip>p{align-self:center;margin:0;padding-left:16px;border-left:1px solid var(--cf-line);color:var(--cf-muted);font-size:8px;line-height:1.5}.cf-rec-count{min-width:105px;border-radius:9px}.cf-rec-count span{max-width:80px;line-height:1.25}.cf-rec-overview{display:flex;align-items:stretch;gap:7px}.cf-rec-overview-item{display:grid;place-items:center;min-width:54px;padding:8px 9px;border:1px solid var(--cf-line);border-radius:8px;background:#fff;text-align:center}.cf-rec-overview-item strong{color:var(--cf-navy);font-size:16px;line-height:1}.cf-rec-overview-item span{margin-top:4px;color:var(--cf-muted);font-size:7px;font-weight:800;letter-spacing:.08em;text-transform:uppercase}.cf-rec-overview-critical{border-top:3px solid #a43b36}.cf-rec-overview-high{border-top:3px solid var(--cf-amber)}.cf-rec-overview-medium{border-top:3px solid #4a7895}.cf-rec-overview-review{border-top:3px solid var(--cf-blue)}.cf-rec-overview-low{border-top:3px solid var(--cf-green)}.cf-rec-card{display:grid;grid-template-columns:44px 1fr;border-left:1px solid var(--cf-line);overflow:hidden;box-shadow:0 5px 16px rgba(16,47,70,.045)}.cf-rec-card-rail{display:flex;justify-content:center;padding-top:17px;background:var(--cf-blue);color:#fff}.cf-rec-card-rail span{font-size:10px;font-weight:850;letter-spacing:.08em}.cf-rec-priority-critical .cf-rec-card-rail{background:#a43b36}.cf-rec-priority-high .cf-rec-card-rail{background:var(--cf-amber)}.cf-rec-priority-medium .cf-rec-card-rail{background:#4a7895}.cf-rec-priority-low .cf-rec-card-rail{background:var(--cf-green)}.cf-rec-card-content{min-width:0}.cf-rec-card-header{display:block;padding:16px 19px 12px}.cf-rec-priority{background:#edf3f6;color:var(--cf-blue)}.cf-rec-title-block h2{font-size:18px;letter-spacing:-.015em}.cf-rec-card-body{background:#fff}.cf-rec-detail{min-height:76px;padding:14px 19px}.cf-rec-question{padding:11px 19px;background:var(--cf-soft)}.cf-rec-list{gap:12px}.cf-rec-groups{display:grid;gap:22px}.cf-rec-group{display:grid;gap:10px;break-inside:auto;page-break-inside:auto}.cf-rec-group-header{display:flex;justify-content:space-between;align-items:end;gap:20px;padding:0 2px 8px;border-bottom:2px solid var(--cf-navy);break-after:avoid;page-break-after:avoid}.cf-rec-group-header p{margin:0;color:var(--cf-blue);font-size:7px;font-weight:850;letter-spacing:.12em;text-transform:uppercase}.cf-rec-group-header h2{margin:3px 0 0;color:var(--cf-navy);font-size:18px;line-height:1.2}.cf-rec-group-header>span{color:var(--cf-muted);font-size:8px;font-weight:800;letter-spacing:.08em;text-transform:uppercase}.cf-rec-group-list{display:grid;gap:12px}.cf-rec-footer{margin-top:8px}.cf-rec-group-header,.cf-rec-card-header,.cf-rec-question,.cf-rec-footer{break-inside:avoid;page-break-inside:avoid}.cf-time-group-header{break-after:avoid-page;page-break-after:avoid}.cf-time-item-first{break-before:avoid-page;page-break-before:avoid}.cf-time-groups{gap:16px}.cf-time-group{gap:7px;padding:14px}.cf-time-list{gap:7px}.cf-time-footer{break-before:avoid-page;page-break-before:avoid}.cf-rec-group-header{break-after:avoid-page;page-break-after:avoid}.cf-rec-card-first{break-before:avoid-page;page-break-before:avoid}.cf-rec-group-list{orphans:2;widows:2}.cf-rec-card{orphans:3;widows:3}.cf-rec-card-body p{orphans:3;widows:3}.cf-rec-footer{break-before:avoid-page;page-break-before:avoid}.cf-rec-groups:last-child,.cf-rec-group:last-child{margin-bottom:0}.cf-checklist{padding:.55in .62in .46in;display:flex;flex-direction:column;gap:22px;min-height:11in}.cf-check-header{display:grid;grid-template-columns:1fr auto;gap:24px;align-items:start;padding-bottom:20px;border-bottom:3px solid var(--cf-navy)}.cf-check-heading-copy{max-width:72%}.cf-check-eyebrow{margin:0;color:var(--cf-blue);font-size:10px;font-weight:800;letter-spacing:.14em;text-transform:uppercase}.cf-check-header h1{margin:7px 0 6px;color:var(--cf-navy);font-size:32px;line-height:1.1;letter-spacing:-.03em}.cf-check-header p{margin:0;color:var(--cf-muted);font-size:11px;line-height:1.5}.cf-check-brand{align-self:flex-start;color:var(--cf-navy);font-size:20px;font-weight:850;letter-spacing:-.04em;text-align:right}.cf-check-brand span{font-size:8px;vertical-align:top}.cf-check-brand small{display:block;margin-top:4px;color:var(--cf-muted);font-size:8px;font-weight:700;letter-spacing:.12em;text-transform:uppercase}.cf-check-summary{display:grid;grid-template-columns:auto 1fr auto;gap:14px;align-items:stretch;padding:13px;border:1px solid var(--cf-line);border-radius:13px;background:linear-gradient(145deg,#fff,#f7f9fa);break-inside:avoid;page-break-inside:avoid}.cf-check-progress,.cf-check-time{display:flex;flex-direction:column;justify-content:center;min-width:92px;padding:10px 14px;border-radius:9px;background:var(--cf-navy);color:#fff;text-align:center}.cf-check-progress strong,.cf-check-time strong{font-size:22px;line-height:1}.cf-check-progress span,.cf-check-time span{margin-top:4px;color:#cbdce5;font-size:7px;font-weight:800;letter-spacing:.08em;text-transform:uppercase}.cf-check-time{background:var(--cf-soft);color:var(--cf-navy)}.cf-check-time span{color:var(--cf-muted)}.cf-check-stats{display:grid;grid-template-columns:repeat(4,1fr);gap:7px}.cf-check-stats>div{display:grid;place-items:center;padding:8px;border:1px solid var(--cf-line);border-radius:8px;background:#fff;text-align:center}.cf-check-stats strong{color:var(--cf-navy);font-size:16px;line-height:1}.cf-check-stats span{margin-top:4px;color:var(--cf-muted);font-size:7px;font-weight:800;letter-spacing:.06em;text-transform:uppercase}.cf-check-phases{display:grid;gap:20px}.cf-check-phase{display:grid;gap:9px;break-inside:auto;page-break-inside:auto}.cf-check-phase-header{display:flex;justify-content:space-between;align-items:end;gap:20px;padding:0 2px 8px;border-bottom:2px solid var(--cf-navy);break-after:avoid;page-break-after:avoid}.cf-check-phase-header p{margin:0;color:var(--cf-blue);font-size:7px;font-weight:850;letter-spacing:.12em;text-transform:uppercase}.cf-check-phase-header h2{margin:3px 0 0;color:var(--cf-navy);font-size:18px;line-height:1.2}.cf-check-phase-progress{display:flex;align-items:baseline;gap:5px;color:var(--cf-muted)}.cf-check-phase-progress strong{color:var(--cf-navy);font-size:15px}.cf-check-phase-progress span,.cf-check-current{font-size:7px;font-weight:800;letter-spacing:.08em;text-transform:uppercase}.cf-check-current{padding:4px 6px;border-radius:999px;background:#eaf1f5;color:var(--cf-blue)}.cf-check-list{display:grid;gap:9px;margin:0;padding:0;list-style:none}.cf-check-item{display:grid;grid-template-columns:38px 1fr;border:1px solid var(--cf-line);border-radius:10px;background:#fff;overflow:hidden;break-inside:avoid;page-break-inside:avoid}.cf-check-marker{display:flex;justify-content:center;padding-top:16px;background:var(--cf-soft)}.cf-check-marker span{display:block;width:13px;height:13px;border:2px solid var(--cf-blue);border-radius:50%}.cf-check-status-complete .cf-check-marker{background:#eaf4ef}.cf-check-status-complete .cf-check-marker span{border-color:var(--cf-green);background:var(--cf-green);box-shadow:inset 0 0 0 3px #eaf4ef}.cf-check-status-active .cf-check-marker{background:#eaf1f5}.cf-check-status-active .cf-check-marker span{background:var(--cf-blue);box-shadow:inset 0 0 0 3px #eaf1f5}.cf-check-status-skipped{opacity:.72}.cf-check-item-content{min-width:0}.cf-check-item-header{padding:14px 16px}.cf-check-labels{display:flex;flex-wrap:wrap;gap:5px;margin-bottom:6px}.cf-check-labels span{display:inline-flex;padding:3px 6px;border-radius:999px;font-size:7px;font-weight:850;letter-spacing:.07em;text-transform:uppercase}.cf-check-status{background:#edf3f6;color:var(--cf-blue)}.cf-check-status-complete .cf-check-status{background:#eaf4ef;color:var(--cf-green)}.cf-check-status-active .cf-check-status{background:#eaf1f5;color:var(--cf-blue)}.cf-check-status-skipped .cf-check-status{background:#f0f1f2;color:var(--cf-muted)}.cf-check-priority{background:var(--cf-warm);color:var(--cf-amber)}.cf-check-required{background:#f7e9e8;color:#943731}.cf-check-optional,.cf-check-minutes{background:var(--cf-soft);color:var(--cf-muted)}.cf-check-item h3{margin:0;color:var(--cf-navy);font-size:14px;line-height:1.3}.cf-check-description{margin:5px 0 0;color:var(--cf-muted);font-size:9px;line-height:1.45}.cf-check-prompt,.cf-check-note{padding:10px 16px;border-top:1px solid var(--cf-line);background:#fbfcfc}.cf-check-note{background:var(--cf-soft)}.cf-check-prompt span,.cf-check-note span{display:block;margin-bottom:4px;color:var(--cf-blue);font-size:7px;font-weight:850;letter-spacing:.1em;text-transform:uppercase}.cf-check-prompt p,.cf-check-note p{margin:0;color:var(--cf-ink);font-size:9px;line-height:1.5}.cf-check-footer{display:flex;justify-content:space-between;gap:24px;margin-top:auto;padding-top:15px;border-top:1px solid var(--cf-line);color:var(--cf-muted);font-size:8px;line-height:1.45}.cf-check-footer p{margin:0}.cf-check-footer p:first-child{max-width:65%}.cf-check-footer strong{color:var(--cf-navy)}.cf-check-progress-track{width:100%;height:4px;margin-top:10px;border-radius:999px;background:rgba(255,255,255,.22);overflow:hidden}.cf-check-progress-track i{display:block;height:100%;border-radius:inherit;background:#fff}.cf-check-phase{padding:16px 16px 14px;border:1px solid var(--cf-line);border-radius:13px;background:linear-gradient(145deg,#fff,#fbfcfc)}.cf-check-phase-current{border-color:#b9d2df;box-shadow:0 7px 18px rgba(31,95,134,.08)}.cf-check-phase-current .cf-check-phase-header{border-bottom-color:var(--cf-blue)}.cf-check-phase-meter{height:4px;margin:-1px 0 3px;border-radius:999px;background:#e7edf0;overflow:hidden}.cf-check-phase-meter span{display:block;height:100%;border-radius:inherit;background:var(--cf-blue)}.cf-check-status-complete .cf-check-item-content{background:linear-gradient(90deg,#fff,#fbfdfc)}.cf-check-status-active{border-color:#b8d1df;box-shadow:0 5px 14px rgba(31,95,134,.07)}.cf-check-phase-progress{flex-wrap:wrap;justify-content:flex-end}.cf-check-item-header>div{width:100%}.cf-check-footer strong{color:var(--cf-navy)}.cf-timeline{padding:.55in .62in .46in;display:flex;flex-direction:column;gap:22px;min-height:11in}.cf-time-header{display:grid;grid-template-columns:1fr auto;gap:24px;align-items:start;padding-bottom:20px;border-bottom:3px solid var(--cf-navy)}.cf-time-heading-copy{max-width:72%}.cf-time-legend{display:flex;flex-wrap:wrap;gap:7px;margin-top:14px}.cf-time-legend span{display:inline-flex;align-items:center;gap:5px;padding:5px 8px;border-radius:999px;font-size:7px;font-weight:850;letter-spacing:.08em;text-transform:uppercase}.cf-time-legend span:before{content:"";width:7px;height:7px;border-radius:50%;background:currentColor}.cf-time-legend-reviewed{background:#eaf4ef;color:var(--cf-green)}.cf-time-legend-current{background:#eaf1f5;color:var(--cf-blue)}.cf-time-legend-upcoming{background:var(--cf-soft);color:var(--cf-muted)}.cf-time-eyebrow{margin:0;color:var(--cf-blue);font-size:10px;font-weight:800;letter-spacing:.14em;text-transform:uppercase}.cf-time-header h1{margin:7px 0 6px;color:var(--cf-navy);font-size:32px;line-height:1.1;letter-spacing:-.03em}.cf-time-header p{margin:0;color:var(--cf-muted);font-size:11px;line-height:1.5}.cf-time-brand{align-self:flex-start;color:var(--cf-navy);font-size:20px;font-weight:850;letter-spacing:-.04em;text-align:right}.cf-time-brand span{font-size:8px;vertical-align:top}.cf-time-brand small{display:block;margin-top:4px;color:var(--cf-muted);font-size:8px;font-weight:700;letter-spacing:.12em;text-transform:uppercase}.cf-time-summary{display:grid;grid-template-columns:1fr auto;gap:14px;padding:13px;border:1px solid var(--cf-line);border-radius:13px;background:linear-gradient(145deg,#fff,#f7f9fa);break-inside:avoid;page-break-inside:avoid}.cf-time-stats{display:grid;grid-template-columns:repeat(4,1fr);gap:7px}.cf-time-stats>div{display:grid;place-items:center;padding:9px;border:1px solid var(--cf-line);border-radius:8px;background:#fff;text-align:center}.cf-time-stats strong{color:var(--cf-navy);font-size:17px;line-height:1}.cf-time-stats span,.cf-time-duration span{margin-top:4px;color:var(--cf-muted);font-size:7px;font-weight:800;letter-spacing:.07em;text-transform:uppercase}.cf-time-duration{display:flex;flex-direction:column;justify-content:center;min-width:110px;padding:10px 14px;border-radius:9px;background:var(--cf-navy);color:#fff;text-align:center}.cf-time-duration strong{font-size:22px;line-height:1}.cf-time-duration span{color:#cbdce5}.cf-time-groups{display:grid;gap:20px}.cf-time-group{display:grid;gap:9px;padding:16px;border:1px solid var(--cf-line);border-radius:13px;background:linear-gradient(145deg,#fff,#fbfcfc);position:relative}.cf-time-group-current{border-color:#b8d1df;box-shadow:0 8px 24px rgba(31,95,134,.08)}.cf-time-group-current:before{content:"";position:absolute;inset:0 auto 0 0;width:4px;border-radius:13px 0 0 13px;background:var(--cf-blue)}.cf-time-group-reviewed{background:linear-gradient(145deg,#fff,#f8fbf9)}.cf-time-group-header{display:flex;justify-content:space-between;align-items:end;gap:20px;padding-bottom:8px;border-bottom:2px solid var(--cf-navy);break-after:avoid;page-break-after:avoid}.cf-time-group-header p{margin:0;color:var(--cf-blue);font-size:7px;font-weight:850;letter-spacing:.12em;text-transform:uppercase}.cf-time-group-header h2{margin:3px 0 0;color:var(--cf-navy);font-size:18px;line-height:1.2}.cf-time-group-state{display:inline-flex;margin-top:7px;padding:3px 7px;border-radius:999px;background:var(--cf-soft);color:var(--cf-muted);font-size:7px;font-weight:850;letter-spacing:.08em;text-transform:uppercase}.cf-time-group-current .cf-time-group-state{background:#eaf1f5;color:var(--cf-blue)}.cf-time-group-reviewed .cf-time-group-state{background:#eaf4ef;color:var(--cf-green)}.cf-time-group-meta{display:flex;align-items:baseline;gap:5px;color:var(--cf-muted)}.cf-time-group-meta strong{color:var(--cf-navy);font-size:15px}.cf-time-group-meta span,.cf-time-group-meta small{font-size:7px;font-weight:800;letter-spacing:.08em;text-transform:uppercase}.cf-time-group-meta small{padding-left:6px;border-left:1px solid var(--cf-line)}.cf-time-group-meter{height:4px;border-radius:999px;background:#e7edf0;overflow:hidden}.cf-time-group-meter span{display:block;height:100%;border-radius:inherit;background:var(--cf-blue)}.cf-time-list{display:grid;gap:9px;margin:0;padding:0;list-style:none}.cf-time-item{display:grid;grid-template-columns:42px 1fr;border:1px solid var(--cf-line);border-radius:10px;background:#fff;overflow:hidden;break-inside:avoid;page-break-inside:avoid}.cf-time-rail{display:flex;justify-content:center;padding-top:15px;background:var(--cf-soft)}.cf-time-rail span{display:grid;place-items:center;width:22px;height:22px;border-radius:50%;background:#fff;border:2px solid var(--cf-blue);color:var(--cf-blue);font-size:8px;font-weight:850}.cf-time-status-reviewed .cf-time-rail{background:#eaf4ef}.cf-time-status-reviewed .cf-time-rail span{border-color:var(--cf-green);background:var(--cf-green);color:#fff}.cf-time-status-current{border-color:#b8d1df;box-shadow:0 5px 14px rgba(31,95,134,.07)}.cf-time-status-current .cf-time-rail{background:#eaf1f5}.cf-time-status-current .cf-time-rail span{background:var(--cf-blue);color:#fff}.cf-time-item-header{padding:14px 16px}.cf-time-labels{display:flex;flex-wrap:wrap;gap:5px;margin-bottom:6px}.cf-time-labels span{display:inline-flex;padding:3px 6px;border-radius:999px;font-size:7px;font-weight:850;letter-spacing:.07em;text-transform:uppercase}.cf-time-status{background:#edf3f6;color:var(--cf-blue)}.cf-time-status-reviewed .cf-time-status{background:#eaf4ef;color:var(--cf-green)}.cf-time-status-current .cf-time-status{background:#eaf1f5;color:var(--cf-blue)}.cf-time-now{background:var(--cf-navy);color:#fff}.cf-time-item-first{break-before:avoid-page;page-break-before:avoid}.cf-time-type,.cf-time-minutes{background:var(--cf-soft);color:var(--cf-muted)}.cf-time-item h3{margin:0;color:var(--cf-navy);font-size:14px;line-height:1.3}.cf-time-objective{margin:5px 0 0;color:var(--cf-muted);font-size:9px;line-height:1.45}.cf-time-prompt,.cf-time-note{padding:10px 16px;border-top:1px solid var(--cf-line);background:#fbfcfc}.cf-time-status-current .cf-time-prompt{background:#f5f9fb}.cf-time-status-current .cf-time-item-header{background:linear-gradient(90deg,#fff,#f8fbfd)}.cf-time-note{background:var(--cf-soft)}.cf-time-prompt span,.cf-time-note span{display:block;margin-bottom:4px;color:var(--cf-blue);font-size:7px;font-weight:850;letter-spacing:.1em;text-transform:uppercase}.cf-time-prompt p,.cf-time-note p{margin:0;color:var(--cf-ink);font-size:9px;line-height:1.5}.cf-time-reference-grid{display:grid;grid-template-columns:1fr 1fr;gap:14px}.cf-time-reference-grid:empty{display:none}.cf-time-questions,.cf-time-guardrails{padding:15px;border:1px solid var(--cf-line);border-radius:10px;background:#fff;break-inside:avoid;page-break-inside:avoid}.cf-time-reference-grid h2{margin:0 0 8px;color:var(--cf-navy);font-size:13px}.cf-time-reference-grid ul{margin:0;padding-left:17px}.cf-time-reference-grid li{margin:4px 0;color:var(--cf-muted);font-size:9px;line-height:1.4}.cf-time-guardrails{background:var(--cf-warm);border-color:#eadfcb}.cf-time-footer{display:flex;justify-content:space-between;gap:24px;margin-top:auto;padding-top:15px;border-top:1px solid var(--cf-line);color:var(--cf-muted);font-size:8px;line-height:1.45}.cf-time-footer p{margin:0}.cf-time-footer p:first-child{max-width:65%}.cf-time-footer strong{color:var(--cf-navy)}@media(max-width:720px){body{padding:0}.cf-executive-summary{min-height:auto;padding:28px 22px}.cf-exec-masthead,.cf-exec-context,.cf-exec-hero-grid,.cf-exec-action-grid{grid-template-columns:1fr;display:grid}.cf-property-header,.cf-rec-header,.cf-check-header,.cf-time-header{display:grid}.cf-rec-heading-copy,.cf-check-heading-copy,.cf-time-heading-copy{max-width:none}.cf-rec-brand,.cf-check-brand,.cf-time-brand{text-align:left}.cf-check-phase{padding:14px 12px}.cf-check-phase-header{align-items:flex-start}.cf-check-phase-progress{justify-content:flex-start}.cf-rec-summary-strip,.cf-check-summary,.cf-time-summary{grid-template-columns:1fr}.cf-rec-summary-strip>p{padding-left:0;border-left:0;border-top:1px solid var(--cf-line);padding-top:12px}.cf-rec-overview{flex-wrap:wrap}.cf-check-stats,.cf-time-stats{grid-template-columns:repeat(2,1fr)}.cf-rec-card{grid-template-columns:34px 1fr}.cf-property-grid,.cf-rec-card-body{grid-template-columns:1fr}.cf-rec-detail+ .cf-rec-detail{border-left:0;border-top:1px solid var(--cf-line)}.cf-exec-context>div{padding:0 0 12px;border-right:0;border-bottom:1px solid var(--cf-line)}.cf-exec-masthead h1{font-size:28px}}@media print{@page{size:letter;margin:0}.cf-report-running-header,.cf-report-running-footer{position:fixed;left:.62in;right:.62in;z-index:20;display:grid;align-items:center;color:#627681;font-size:7px;letter-spacing:.08em;text-transform:uppercase}.cf-report-running-header{grid-template-columns:auto 1fr auto;column-gap:14px}.cf-report-running-footer{grid-template-columns:auto minmax(0,1fr) auto auto;column-gap:12px}.cf-report-running-footer-paged{grid-template-columns:auto minmax(0,1fr) auto auto auto}.cf-shell-running-page{min-width:54px;text-align:right;font-variant-numeric:tabular-nums}.cf-shell-running-page:after{content:" " counter(page) " of " counter(pages)}.cf-shell-running-document,.cf-shell-running-contact{overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.cf-shell-running-document{text-align:center}.cf-shell-running-contact{text-align:center}.cf-shell-running-reference{font-variant-numeric:tabular-nums}.cf-report-running-header{top:.22in;padding-bottom:5px;border-bottom:1px solid #dce5e9}.cf-report-running-footer{bottom:.18in;padding-top:5px;border-top:1px solid #dce5e9}.cf-report-cover~.cf-report-running-header,.cf-report-cover~.cf-report-running-footer{display:grid}.cf-report-cover{box-shadow:none;-webkit-print-color-adjust:exact;print-color-adjust:exact}html,body{background:#fff}body{padding:0}.cf-print-section{max-width:none;margin:0;box-shadow:none}.cf-timeline{width:8.5in;min-height:11in;break-after:page;page-break-after:always;-webkit-print-color-adjust:exact;print-color-adjust:exact}.cf-checklist{width:8.5in;min-height:11in;break-after:page;page-break-after:always;-webkit-print-color-adjust:exact;print-color-adjust:exact}.cf-recommendations{width:8.5in;min-height:11in;break-after:page;page-break-after:always;-webkit-print-color-adjust:exact;print-color-adjust:exact}.cf-property-summary{width:8.5in;min-height:11in;break-after:page;page-break-after:always;-webkit-print-color-adjust:exact;print-color-adjust:exact}.cf-executive-summary{width:8.5in;min-height:11in;padding:.55in .62in .46in;break-after:page;page-break-after:always;-webkit-print-color-adjust:exact;print-color-adjust:exact}.cf-exec-score-card,.cf-exec-summary-card,.cf-exec-panel{break-inside:avoid;page-break-inside:avoid}.cf-time-summary,.cf-time-group,.cf-time-group-header,.cf-time-group-meter,.cf-time-item,.cf-time-item-header,.cf-time-prompt,.cf-time-note,.cf-time-reference-grid>section,.cf-time-footer,.cf-check-summary,.cf-check-phase,.cf-check-phase-header,.cf-check-phase-meter,.cf-check-item,.cf-check-item-header,.cf-check-prompt,.cf-check-note,.cf-check-footer,.cf-rec-summary-strip,.cf-rec-group-header,.cf-rec-card,.cf-rec-card-header,.cf-rec-card-body,.cf-rec-question,.cf-rec-footer{break-inside:avoid;page-break-inside:avoid}.cf-rec-group-header{break-after:avoid-page;page-break-after:avoid}.cf-rec-card-first{break-before:avoid-page;page-break-before:avoid}.cf-rec-groups{gap:18px}.cf-rec-group{gap:8px}.cf-rec-group-list{gap:10px}.cf-rec-footer{break-before:avoid-page;page-break-before:avoid}.cf-report-body>.cf-print-section:last-child{break-after:auto;page-break-after:auto}}';

  function buildHtmlDocument(sectionOutputs, model, options) {
    const language = typeof options?.language === 'string' && options.language.trim() ? options.language.trim() : 'en';
    const title = typeof options?.title === 'string' && options.title.trim() ? options.title.trim() : 'CoverageFit Consultation';
    const reportShell = resolveReportShell(options);
    const shell = reportShell.compose(sectionOutputs, model, options?.reportShellOptions || options);
    const body = shell.html;
    const html = `<!doctype html>\n<html lang="${language}">\n<head>\n<meta charset="utf-8">\n<meta name="viewport" content="width=device-width, initial-scale=1">\n<title>${title}</title>\n<style>${PRINT_DOCUMENT_CSS}</style>\n</head>\n<body>\n${body}\n</body>\n</html>`;
    return deepFreeze({ html, shell });
  }

  const htmlRenderer = Object.freeze({
    id: 'coveragefit-html-renderer',
    name: 'CoverageFit HTML Renderer',
    version: '1.6.0',
    mediaType: 'text/html',
    extension: 'html',
    capabilities: Object.freeze(['html', 'browser', 'print-preview', 'composed-sections', 'report-shell', 'paged-media-page-counters']),
    render(model, options) {
      const settings = options || {};
      const composer = resolveComposer(settings);
      const composerOptions = {
        ...(clone(settings.composerOptions) || {}),
        sectionRegistry: settings.sectionRegistry || settings.composerOptions?.sectionRegistry,
        visibilityEngine: settings.visibilityEngine || settings.composerOptions?.visibilityEngine
      };
      Object.keys(composerOptions).forEach(key => composerOptions[key] == null && delete composerOptions[key]);
      const document = composer.compose(model, composerOptions);
      const sectionOutputs = renderComposedSections(document, model, settings);
      const renderedDocument = buildHtmlDocument(sectionOutputs, model, settings);
      const html = renderedDocument.html;
      const shell = renderedDocument.shell;
      return deepFreeze({
        type: 'html',
        mediaType: 'text/html',
        html,
        model,
        document,
        sectionOutputs,
        diagnostics: {
          valid: document.diagnostics.valid,
          composedSectionCount: document.sections.length,
          renderedSectionCount: sectionOutputs.length,
          hiddenSectionCount: document.hiddenSections.length,
          sectionIds: sectionOutputs.map(section => section.id),
          rendererVersion: this.version,
          reportShellVersion: shell.version,
          reportShellValid: shell.diagnostics.valid,
          reportShellCertified: shell.diagnostics.certified,
          reportShellWarnings: shell.diagnostics.warnings,
          pageNumberingMode: shell.pageNumberingMode
        }
      });
    }
  });

  registerRenderer('html', htmlRenderer, {
    default: true,
    metadata: {
      production: true,
      certified: true,
      capabilities: ['html', 'browser', 'print-preview', 'composed-sections', 'report-shell', 'paged-media-page-counters']
    }
  });

  return Object.freeze({
    VERSION,
    DEFAULT_RENDERER_TYPE,
    registerRenderer,
    unregisterRenderer,
    getRenderer,
    getRendererMetadata,
    hasRenderer,
    listRenderers,
    setDefaultRenderer,
    getDefaultRendererType,
    getDefaultRenderer,
    resolveRenderer,
    supports,
    validateRenderer,
    getDiagnostics
  });
});
